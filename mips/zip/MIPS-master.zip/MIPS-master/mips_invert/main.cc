#include"mips_invert.h"

int main(){
    MipsInvert m("info.txt");
    m.Convert("binary.txt" , "assemble.txt");
}