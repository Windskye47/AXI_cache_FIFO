#include"mips.h"

int main(){
    MIPS m("instructor");

    m.convertToBinary("assemble" , "binary");
}